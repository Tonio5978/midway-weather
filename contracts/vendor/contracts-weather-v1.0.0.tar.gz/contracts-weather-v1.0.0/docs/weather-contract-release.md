# contracts-weather release runbook

Weather uses the same package-qualified annotated tag, deterministic Git archive,
`gzip -n`, SHA-256 sidecar, retained Actions artifact, and GitHub release model as
[contracts-core](contract-release.md). This is contract publication, not a
Weather deployment. The approved initial artifact is `contracts-weather/v1.0.0`;
its API/schema major is 2 and its operation is `GET /api/v2/summary/current`.

## Source and dependency verification

1. Keep the approved schemas, fixtures, specification, VERSION, manifest, and
   `contracts-core.lock.json` together. Do not change approved semantics during
   publication. The initial lock pins `contracts-core/v1.0.0` at
   `6ebe0318207a611a1a553a1cfba036aa96223260`, archive
   `contracts-core-v1.0.0.tar.gz`, SHA-256
   `719d4e922e97c6c3e6ed18c48c016c51a3ef5bc1496a6536e1e46d8b49089c53`.
2. Run `npm ci` and `npm test`. Verify core package/version/tag/source provenance
   and compare the three common schemas byte-for-byte with the pinned release.
   Never replace the dependency with mutable `main` or republish core.
3. Commit the release source. Download the existing core release archive named
   in the lock. Build and verify a candidate from the exact committed source:

   ```bash
   npm run build:contracts-weather -- --candidate HEAD
   npm run verify:weather-archive -- dist/contracts-weather-v1.0.0.tar.gz /path/to/contracts-core-v1.0.0.tar.gz HEAD
   ```

   Candidate mode creates no tag or release. The verifier checks the core digest,
   Weather sidecar and allowlisted inventory, compares every archived file with
   the intended Git commit, then reruns the full schema/fixture/semantic suite
   against the extracted Weather archive plus the independently pinned core
   archive. Negative fixtures must fail for their documented reasons.
4. Review the PR for approved scope, passing CI, and absence of application or
   runtime changes. Merge to `main`, synchronize, and repeat candidate validation
   against the exact merge commit. Record that commit before tagging.

## Immutable publication

5. Confirm the new tag/release does not already exist and repository immutable
   releases are enabled. Enabling this protection applies to future releases;
   existing core release assets and tags must remain untouched.
6. Create an annotated `contracts-weather/v<version>` tag on the validated exact
   `main` commit. Confirm its peeled commit and push only that tag. Do not move,
   recreate, or force-push it.
7. The tag workflow repeats validation and dependency verification, builds the
   archive, and retains the archive/sidecar as a 90-day Actions artifact. It
   creates a draft GitHub release with both assets, downloads and verifies the
   draft assets, then publishes the release, locking its tag and assets. It
   confirms GitHub reports `immutable: true`. There is no overwrite/repair path.
8. Download the published archive and sidecar. Repeat archive verification using
   the recorded exact source commit and core archive. Confirm the remote tag
   resolves to that commit. Record tag, source, archive, SHA-256, dependency
   provenance, and successful CI in the ecosystem publication record.
9. Never amend a published release tag or replace its assets. If an error is
   found after publication, stop and report; corrections require a new version
   under the accepted compatibility model.

The Weather archive contains only `contracts/contracts-weather`,
`contracts/weather/v2`, this runbook, and its versioned release notes. Common
schemas come only from the core archive. Validation tooling is versioned in the
same source commit; consumers do not need a runtime client package.

Publication does not implement v2, change Weather v1, migrate Kitchen, introduce
a Rotator integration, or deploy anything. Producer implementation requires
separate explicit authorization in the existing Weather application.
