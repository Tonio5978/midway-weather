# contracts-weather v1.0.0

Initial approved stable Weather-domain contract artifact. The API/schema major
is v2: public, unauthenticated, read-only `GET /api/v2/summary/current`.

Includes the canonical success/error schemas, Weather-owned specification,
13 valid examples, 8 negative fixtures, artifact identity, and pinned
`contracts-core/v1.0.0` dependency provenance. The core archive SHA-256 is
`719d4e922e97c6c3e6ed18c48c016c51a3ef5bc1496a6536e1e46d8b49089c53` at source
`6ebe0318207a611a1a553a1cfba036aa96223260`. Common schemas are not duplicated.

The contract distinguishes observation, observed daily extrema, forecast, and
interpretation freshness; availability and retained data; explicit units and
timestamps; and domain classifications from consumer presentation. Compatibility
wording explicitly treats making a previously non-null field nullable as breaking.

The tagged source is revalidated before publication, including the full suite on
the exact archive with the pinned core dependency. The release provides
`contracts-weather-v1.0.0.tar.gz` and its `.sha256` sidecar. Resolve the annotated
tag for the exact source commit and verify the checksum before adoption.

No producer is implemented or deployed by this release. Weather v1, application
identity, databases, providers, consumers, discovery, and runtime remain unchanged.
The future v2 producer belongs in the existing Weather application and requires
separate authorization.
