# Weather current summary v2

Status: **APPROVED for immutable publication as contracts-weather/v1.0.0.** August 31, 2026.
Producer implementation has not begun. Publication evidence belongs to the GitHub release and ecosystem record.
Weather owns the domain semantics and evolution. `midway-platform` holds and
distributes the neutral contract; it is not a Weather runtime or domain authority.
ADR-009 is accepted and is not being reopened.

## Identity and operation

| Identity | Approved value |
| --- | --- |
| Contract family / immutable artifact | `contracts-weather` / `1.0.0` |
| Immutable provenance tag | `contracts-weather/v1.0.0` |
| Capability | `weather.summary.current` |
| Schema capability identifier | `midway.weather.summary.current/v2` |
| Runtime/API major | `2` |
| Operation | `GET /api/v2/summary/current`, JSON |
| Success schema | [summary-current.schema.json](summary-current.schema.json) |
| Error schema | [error.schema.json](error.schema.json) |
| Exact common-contract dependency | `contracts-core/v1.0.0` |

The artifact starts at **1.0.0 because owner approval establishes a stable
cross-application compatibility commitment**, not because core uses that version.
`0.x` would wrongly describe the approved stable
contract as unstable. API/schema v2 replaces an already consumed, incompatible
Weather v1 envelope. The first neutral artifact has its own version history.
No Composer/npm client package is introduced; `package.json` here describes the
language-neutral release bundle, following core's convention.

Every success and error carries standard ADR-003 `meta.request_id` and
`meta.generated_at`, plus required `meta.contract` identifying the capability,
API major, and exact adopted Weather artifact version. The artifact version is
not an application version or a deployment identifier. Weather remains
`midway-weather`; its release identity belongs in ADR-004 `/api/v1/version` and
the ADR-008 release manifest. A later producer may deploy repeatedly against this
same artifact. Schema `$id` URLs are identifiers, not a runtime schema host.

The operation represents Weather's configured location, not a selectable station
or multi-location API. No hostname, coordinates, station identity, instance ID,
or physical deployment path is part of this logical contract. Orchestrator owns
capability/endpoint discovery. Use discovery where adopted; environment-specific
endpoint configuration remains permissible during migration. Call Weather
directly; Orchestrator is not a Weather proxy.

## One cohesive projection

All listed top-level data groups are required. Required nullable groups make
absence explicit without making optional enrichment a prerequisite for a useful
temperature reading.

| Group | Required contents / null rules | Meaning |
| --- | --- | --- |
| `availability` | `available` or `degraded` on success | Operational condition of this projection capability, not whole-application health |
| `timezone` | IANA timezone name | Calendar-day interpretation for this Weather location |
| `observation` | Non-null; `temperature_f`, `observed_at`, `retrieved_at`, `freshness`, `last_known_good` | Latest usable outdoor temperature with trustworthy observation time; retrieval is explicitly nullable |
| `observation.solar_radiation_w_m2` | Optional and nullable | Observed irradiance used by Kitchen's existing atmosphere rendering; absence is not zero |
| `observed_today` | Object or null; period, `as_of_at`, freshness, numeric high/low | Observed extrema so far for this local day; not predicted whole-day extrema |
| `forecast_today` | Object or null; period, `retrieved_at`, freshness, `last_known_good`, nullable high/low/condition | Today's forecast only; at least one of high, low, or condition must be usable |
| `interpretation` | Object or null; `based_on`, freshness, nullable `atmosphere`; optional nullable `summary` | Weather-owned combined interpretation, potentially informed by today's forecast |

Temperatures are JSON numbers, not numeric strings. Optional measurements that
are missing, invalid, or out of their documented domain become absent/null,
never fabricated zeroes. A missing usable temperature or trustworthy observation
time prevents a successful projection. Unusable forecast data becomes null and
does not invalidate a usable observation. `observed_today` is null when no usable
observations exist for the current local date; yesterday's extrema must never be
renamed today. In each high/low pair, low must not exceed high.

This separation is necessary: current v1 prefers cached observed daily extrema
and falls back to forecast high/low, sometimes independently per value. Calling
that mixed result a forecast would change its meaning. Consumers can preserve
the current display preference using observed extrema when present and forecast
values otherwise, while retaining each selected value's basis and freshness.
This is selection for presentation, not provider fallback or canonical Weather
last-known-good selection. Missing high/low must be handled as absent in the
future adapter, not coerced to zero. No current consumer is switched to v2 here.

## Timestamps and freshness

All machine timestamps are RFC 3339 with an explicit timezone. UTC transport is
preferred; equivalent explicit offsets are accepted. Calendar windows are
half-open `[starts_at, ends_at)` from local midnight to the next local midnight
in `data.timezone`, including 23/25-hour DST days. The response instant must lie
inside each returned daily window.

| Field | Semantics |
| --- | --- |
| `meta.generated_at` | When Weather assembles/evaluates this response and its freshness, not when its data was observed |
| `observation.observed_at` | Actual observation instant, at the precision Weather retained; never the HTTP response, cache-read, or successful repoll time |
| `observation.retrieved_at` | Retrieval of this selected observation, only when known; null for the legacy storage model's unproven provenance |
| `observed_today.as_of_at` | Newest usable observation included in this day's extrema; not aggregate cache-write time |
| `forecast_today.retrieved_at` | Retrieval of this exact retained daily forecast, not newest retrieval among unrelated rows and not provider model issuance |
| Daily `period` | Forecast-valid calendar day, or observed aggregation day; separate from retrieval and response generation |

There is no provider issuance/update timestamp that Weather can substantiate
today, so none is required or invented. A collection-status `last_success_at`
is an operational poll time, not provenance for an arbitrarily selected row.
Forecast validity does not prove freshness: a forecast for today can be stale.

Weather computes and publishes the freshness deadlines; consumers do not need
to learn provider cadence or guess thresholds. There is no top-level freshness
bit. All states are evaluated at `meta.generated_at`:

| Component | Vocabulary | Initial Weather-owned policy |
| --- | --- | --- |
| Observation | `fresh`, `delayed`, `stale` | `fresh_until = observed_at + 10 minutes`; `stale_after = observed_at + 20 minutes` |
| Observed daily extrema | `fresh`, `delayed`, `stale` | Same windows anchored to **its own** `as_of_at` |
| Forecast | `fresh`, `stale` | `fresh_until = retrieved_at + 3 hours` |
| Interpretation | `fresh`, `delayed`, `stale` | Worst freshness of every considered input; earliest corresponding deadlines |

`fresh` means response time <= `fresh_until`; `delayed` means later than
`fresh_until` but <= `stale_after`; `stale` means later than `stale_after`.
Forecast has no delayed interval: its stale deadline equals its fresh deadline.
The observation intermediate state is retained because Weather already uses and
tests it; it is not a newly invented vocabulary. No `no_data` freshness value is
needed: absence uses a nullable component or the unavailable error.

`interpretation.based_on` includes `observation` and includes `forecast_today`
whenever that component is present. The initial interpreter considers both even
if observed rain wins its precedence decision. Its `fresh_until` is the minimum
input fresh deadline; its `stale_after` is the minimum input stale deadline
(using the forecast fresh deadline as its stale deadline). Thus a fresh
observation cannot refresh forecast-derived atmosphere or summary text. If a
historical pressure trend informs summary wording, its window is anchored to
the selected observation and calculated from local observations; a new trend
cache/source with an independent refresh lifecycle would require explicit
provenance before use. Missing history means no trend claim.

Weather owns configuration of these windows. The initial defaults deliberately
reuse `weather.staleness` policy, not Weather UI preferences or summary-cache
TTL. A valid deployment may tune nonnegative windows with observation fresh
window <= stale window. Responses publish the resulting deadlines. Tuning the
documented configurable windows does not change their meaning; redefining age
basis, state meaning, deadline inclusivity, or dependency inheritance is breaking.
Known stale or suspect inputs must not receive renewed deadlines just because
they were read from storage. Unknown/future source times must not be labeled
fresh; omit the unusable component or return unavailable.

## Availability and retained data

`available` means this projection's observation and forecast refresh functions
have no known impairment and can provide their supported components. Stale data
does not by itself prove an operational failure: a successful poll can return
an unchanged old station reading. That can truthfully be available + stale.

`degraded` means useful observation data exists but refresh, provenance, or
forecast delivery is impaired. Missing forecast, a known refresh failure with
retained data, or unavailable operational evidence is degraded. Optional solar
irradiance, optional prose, or legitimately absent observed extrema do not
automatically degrade the capability. Weather derives this state; consumers and
Orchestrator do not recalculate it. Application health remains ADR-004 work.

`last_known_good` on observation and forecast is true when Weather deliberately
serves that retained component following refresh failure. It is false for normal
reads of stored data, including old data successfully retrieved again. True
requires overall degraded availability but does **not** rewrite observation or
forecast times. Retained data may still be inside its normal freshness window;
the explicit flag and degradation disclose the failed refresh. Once its original
deadline passes it is delayed/stale, regardless of response generation time.
Ordinary stale + available data and fresh + degraded retained data are both valid.

There is no new universal retention-age cutoff in this contract. Weather selects
usable retained records within its own retention/quality policy; age always
remains exposed. Forecast rows must still apply to today's local date. Consumers
may impose stricter age limits and must define bounded network timeouts/retries
and bounded, non-authoritative cache policy. Cached responses preserve all source
times, retention flags, and freshness metadata; cached `fresh` is only a report
as of the original generation instant. Weather's deadlines allow it to expire
without inventing a competing freshness policy. Do not call providers directly
to reconstruct canonical Weather when Weather is unavailable.

## Classifications, units, and presentation boundary

The shared Weather classification vocabulary is **open**. Known initial values:

| Value | Weather meaning |
| --- | --- |
| `clear` | Clear conditions in the considered evidence |
| `partly_cloudy` | Partial cloud cover |
| `overcast` | Overcast conditions |
| `fog` | Fog conditions |
| `light_rain` | Light liquid precipitation, including drizzle/light showers |
| `rain` | Rain/showers |
| `heavy_rain` | Heavy liquid precipitation/showers |
| `snow` | Snow or snow showers, without a severity guarantee |
| `thunderstorm` | Thunderstorm conditions indicated by the considered evidence |
| `thunderstorm_with_hail` | Forecast classification indicating a thunderstorm with hail, **not** an observed hail report or severe-weather alert |

`forecast_today.condition` describes daily forecast context.
`interpretation.atmosphere` describes Weather's combined interpretation using
observations and available daily forecast. Neither asserts station confirmation
of every phenomenon. Observed hourly precipitation can replace the broad daily
rain/cloud condition, while forecast thunderstorm/hail/snow context remains
significant, matching existing Weather precedence. Missing evidence must produce
null, not the legacy unconditional clear default. Unknown future strings are
treated as unsupported/unknown with neutral presentation; consumers must not
reinterpret them through raw provider codes. Producers emit only vocabulary
documented by their adopted artifact.

The existing `severe-storm` label is based on a daily forecast code, not an alert
feed. It is deliberately replaced by the specific, qualified
`thunderstorm_with_hail` classification. No `severe` boolean, warning object,
alert severity, alert expiry, notification guarantee, or safety-critical promise
is included. Kitchen may map that classification to its existing visual effect;
it owns the effect, its intensity, and whether stale data should activate it.
Any future alert operation needs a separate temporal/coverage/authority review.

All temperatures use **degrees Fahrenheit**, explicitly encoded in `_f` field
names. Both the existing Weather normalization and Kitchen display already use
Fahrenheit; choosing one fixed unit avoids runtime ambiguity and unnecessary
per-measurement wrappers. `solar_radiation_w_m2` uses **watts per square metre**.
No other numeric weather measurements are exposed initially. Consumers own
presentation conversion, rounding, suffixes, formatting, and styles. Temperature
mood keys, icon/animation keys, numeric visual severity weights, CSS, themes,
layout instructions, and presentation-profile identifiers are excluded.

`interpretation.summary` retains demonstrated value as advisory Weather-owned
natural-language interpretation. It is optional, nullable, and not a programming
interface: exact wording, phrase rotation, and phrase IDs are not contracts.
Do not put HTML, styling, display instructions, or safety assurances in it.

## Authentication, errors, and HTTP behavior

This read-only, data-minimized operation is **public/unauthenticated**, continuing
the existing summary access policy. This is intentional public data, not trust
in a caller's IP or hostname. No credentials, precise location, indoor readings,
provider diagnostics, or private household content are exposed. The accepted
roadmap explicitly permits this and defers the auth pilot to protected household
data. No Weather ability is registered or inferred from ADR examples. HTTPS is
the production transport; no new authentication infrastructure is required.

| HTTP | Envelope | Meaning |
| --- | --- | --- |
| 200 | ADR-003 `data` + `meta` | Usable projection, including stale or degraded data |
| 503 | ADR-003 `error` + `meta`; `weather_data_unavailable`; `error.details.availability = unavailable` | No usable observation or no usable retained fallback; no successful `data` body |
| 500 | ADR-003 error; `internal_error` | Unexpected failure to generate a projection, without leaking internals |

Error code is machine-readable; message wording is not stable. Other protocol
failures use ADR-003 status and envelope semantics; this is not an exhaustive
infrastructure error registry. Clients tolerate unknown error codes safely.
This operation has no required identity or ability and therefore no canonical
401/403 examples. A future protected operation must declare its abilities and
use 401 for missing/invalid identity and 403 for a valid principal without the
required ability, with local verification under ADR-005. Changing this public
operation to require authentication is breaking. Degradation is never an auth
failure. Health's deliberate HTTP 503 `data` exception does not apply here.

Preserve a valid `X-Midway-Request-ID`, generate a valid one otherwise, using the
released core request-ID rules. Return `Cache-Control: no-store, max-age=0` to
avoid intermediary reuse as in the existing endpoint; this is distinct from a
consumer's explicit resilience cache. No `ttlSeconds` promise or universal
polling interval is introduced. The later producer must serve local data without
request-time provider calls, refreshes, or writes to domain state.

## Compatibility

Existing `/api/v1/summary/current` and `/api/display/weather` remain unchanged
through the independently deployed consumer migration. The current Kitchen
adapter deliberately rejects v2; do not change its configured URL until its
separate migration is implemented and validated. Consult Orchestrator's adopted
dependency inventory before retiring an old version. No new application identity,
hostname, datastore, provider integration, or parallel deployment is needed.

Objects allow unknown optional properties and consumers ignore them. All defined
required fields must remain present, including nullable groups. Omitting an
optional field and supplying null both mean unavailable/not supplied, never zero.
Adding an optional field or metadata member is compatible; adding a required
field, removing any documented field, changing units/meaning/type, narrowing
accepted inputs, making a previously non-null field nullable, or changing structure is breaking.

Availability, freshness, and `based_on` are **closed** vocabularies: new states or
dependencies require a new API/schema major and an appropriate artifact major.
The Weather classification strings and error codes are **open**: documented
new values may be additive minor releases because every conforming consumer must
already handle unknown values safely. Reinterpreting an existing value is breaking.
Required `meta.contract.version` remains 2; compatible artifact `1.x.y` values
are accepted by this schema. Producer adoption records the exact release it used;
consumers pin their schema artifact, while tolerating compatible later responses.
Publication never updates an application automatically.

## Validation and release boundary

`npm test` reuses core's pinned AJV 2020-12 / ajv-formats validator and fixture
registry, then checks Weather timestamp relationships, HTTP behavior, freshness
inheritance, DST/day bounds, numeric consistency, and additive compatibility.
These semantic checks supplement JSON Schema; a schema-valid response alone
does not prove it truthfully represents source state. Producer tests must later
prove that mapping. No client or producer implementation is included here.

Canonical examples under [examples/valid](examples/valid): fresh/available,
delayed observation, stale/available, degraded last-known-good, fresh observation
with stale forecast, degraded recent retained data, partial optional data,
missing forecast, unknown interpretation, forecast hail classification, 503
unavailable, 500 internal error, and day rollover with no observed extrema yet.
All timestamps/data are synthetic examples.
Negative fixtures cover missing request ID, unzoned time, null required
temperature, unavailable success, delayed forecast, wrong API major, a legacy
hyphenated presentation label, and a mixed success/error envelope.

The [artifact manifest](../../contracts-weather/package.json) and
[core dependency lock](../../contracts-weather/contracts-core.lock.json) reuse
the established identity/provenance model. The archive uses the same
package-qualified immutable tag, deterministic `git archive` + `gzip -n`, SHA-256
sidecar, retained GitHub release assets, and consumer lock conventions as core.
Weather's archive includes its manifest/lock, `contracts/weather/v2` schemas,
this specification, and examples; the exact core dependency is resolved separately
from its already published archive, never from mutable `main`. Consumers register
the pinned common schemas before Weather schemas. Do not duplicate common schemas.

The approved release follows the existing platform publication mechanism; see
[the Weather release runbook](../../../docs/weather-contract-release.md).
No common schema is copied into the Weather archive. Producer implementation and
consumer migration remain separate, explicitly authorized steps. Contract
publication is not evidence of producer or hosted conformance and does not
activate `/api/v2/summary/current`.

The contract approval gate is complete. Do not begin producer implementation
without explicit authorization.
