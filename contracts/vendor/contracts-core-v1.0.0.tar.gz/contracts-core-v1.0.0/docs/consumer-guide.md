# contracts-core consumer guide

## Obtain and verify

Download the archive and matching `.sha256` sidecar from the `contracts-core/v1.0.0` GitHub release, then verify it before extraction:

```bash
shasum -a 256 -c contracts-core-v1.0.0.tar.gz.sha256
```

Commit or otherwise pin the exact contract version used by application tests. Do not make runtime service availability depend on GitHub or this repository.

## Canonical schemas

| Capability | Schema |
| --- | --- |
| Success envelope | `contracts/common/v1/success-envelope.schema.json` |
| Error envelope | `contracts/common/v1/error-envelope.schema.json` |
| Health | `contracts/health/v1/health.schema.json` |
| Version | `contracts/version/v1/version.schema.json` |
| Release manifest | `contracts/release-manifest/v1/release-manifest.schema.json` |

`metadata.schema.json` is a referenced supporting schema and must be registered with validators before compiling health, version, or envelope schemas.

## HTTP behavior

- Preserve a valid `X-Midway-Request-ID`; generate a valid identifier otherwise.
- Return the identifier as `meta.request_id`.
- Return an RFC 3339 timestamp with timezone as `meta.generated_at`.
- Return HTTP 200 for health `available` or `degraded`.
- Return HTTP 503 with the valid health envelope for intentionally reported `unavailable`.
- Use the ADR-003 error envelope if health evaluation itself fails.
- Derive `/api/v1/version` from the deployed release manifest.

Application-specific domain payloads and health criticality remain application-owned.

## Release manifest integrity

The manifest requires either `content` integrity or `artifact` integrity. `content` may identify the digest of a file-checksum manifest inside the release when embedding an archive checksum would be circular. The transferred archive must still have a separately verified checksum, and the retained archive/sidecar must remain available outside production through the rollback window.

