# Contract versioning and compatibility

## Independent package release

`contracts-core` is independently versioned with Semantic Versioning. Its immutable provenance tag is package-qualified:

```text
contracts-core/v1.0.0
```

The package version identifies the released bundle. Each schema `$id` and directory `v1` identifies a protocol/schema major version. Those are related but distinct version dimensions.

## Compatibility rules

Within a schema major version, compatible changes may add optional fields, examples, or clarifying documentation without changing existing meanings. Consumers must ignore unknown optional fields.

A new schema major version is required to remove a field, make an optional field required, narrow a field type or enum incompatibly, rename a field, change an established meaning, or otherwise reject a previously conforming instance.

Schema files permit unknown optional properties intentionally. Producer conformance tests remain responsible for detecting misspelled or unintended fields in application-owned payload construction.

## Consumer pinning

Production consumers pin an immutable `contracts-core` release artifact or tag and record the adopted version in their application release metadata. They must not fetch `main` at runtime or depend on a local `midway-platform` checkout in production.

Adopting a newer compatible package release is an intentional application change with application tests and deployment validation. Publishing a package release does not alter any deployed application.

## Request identifiers

Version 1 accepts request IDs from 1 to 128 characters using ASCII letters, digits, period, underscore, colon, and hyphen, with an alphanumeric first character. Invalid incoming values must be replaced rather than reflected.

## Release immutability

Tags and release archives are immutable. A defect is corrected in a new package version; published tags or archives are never moved or replaced.

