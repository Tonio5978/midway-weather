# Published capability inventory

## contracts-core/v1.0.0

| Capability | Contract ID | Authority |
| --- | --- | --- |
| Success envelope | `midway.common.success-envelope/v1` | ADR-003 |
| Error envelope | `midway.common.error-envelope/v1` | ADR-003 |
| Health response | `midway.health/v1` | ADR-004 |
| Version response | `midway.version/v1` | ADR-004 |
| Release manifest | `midway.release-manifest/v1` | ADR-008 |

This release contains language-neutral contracts and validation fixtures only. It publishes no runtime service, domain model, authentication package, Weather contract, UI package, PHP implementation, Laravel adapter, or deployment authority.

